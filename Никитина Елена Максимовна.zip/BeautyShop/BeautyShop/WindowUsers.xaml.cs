﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace BeautyShop
{
    /// <summary>
    /// Логика взаимодействия для Brons.xaml
    /// </summary>
    public partial class WindowUsers : Window
    {
        public WindowUsers()
        {
            InitializeComponent();
        }

        private void ButtonBrons_Click(object sender, RoutedEventArgs e)
        {
            MessageBox.Show("Здесь вы можете забронировать окно", "Сообщение");
            Brons windowuser = new Brons();
            windowuser.Show();
            this.Close();
        }

        private void ButtonInfo_Click(object sender, RoutedEventArgs e)
        {
            MessageBox.Show("Информация о нас", "Сообщение");
            Contakti windowuser = new Contakti();
            windowuser.Show();
            this.Close();
        }

        private void ButtonCatalogPers_Click(object sender, RoutedEventArgs e)
        {
            MessageBox.Show("Здесь вы можете посмотреть обслуживающий персонал", "Сообщение");
            Personals windowuser = new Personals();
            windowuser.Show();
            this.Close();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            Avtoriz windowuser = new Avtoriz();
            windowuser.Show();
            this.Close();
        }

        private void ButtonCatalogUslug_Click(object sender, RoutedEventArgs e)
        {
            Uslugi windowuser = new Uslugi();
            windowuser.Show();
            this.Close();
        }
    }
}
