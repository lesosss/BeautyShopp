﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace BeautyShop
{
    /// <summary>
    /// Логика взаимодействия для Contakti.xaml
    /// </summary>
    public partial class Contakti : Window
    {
        public Contakti()
        {
            InitializeComponent();
        }

        private void ButtonExzit_Click(object sender, RoutedEventArgs e)
        {
            WindowUsers windowuser = new WindowUsers();
            windowuser.Show();
            this.Close();
        }
    }
}
