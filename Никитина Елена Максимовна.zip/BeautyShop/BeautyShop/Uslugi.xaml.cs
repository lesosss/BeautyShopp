﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace BeautyShop
{
    /// <summary>
    /// Логика взаимодействия для Personal.xaml
    /// </summary>
    public partial class Uslugi : Window
    {
        BeautyShopEntities db = new BeautyShopEntities();
        public Uslugi()
        {
            InitializeComponent();

            var personal1 = (from u in db.Usluga select u).ToArray();
            DBA.ItemsSource = personal1;
        }


        private void Button_Click(object sender, RoutedEventArgs e)
        {
            WindowUsers window = new WindowUsers();
            window.Show();
            this.Close();
        }
    }

}