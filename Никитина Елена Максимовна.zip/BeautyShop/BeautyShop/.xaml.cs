﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace BeautyShop
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class GlavWindow : Window
    {
        public GlavWindow()
        {
            InitializeComponent();
        }


        private void ButtonAvtoriz_Click_1(object sender, RoutedEventArgs e)
        {
            Avtoriz mainWindow = new Avtoriz();
            mainWindow.Show();
            this.Close();
        }
    }
}
