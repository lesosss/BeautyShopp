﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace BeautyShop
{
    /// <summary>
    /// Логика взаимодействия для Avtoriz.xaml
    /// </summary>
    public partial class Avtoriz : Window
    {
        BeautyShopEntities db = new BeautyShopEntities();
        public Avtoriz()
        {
            InitializeComponent();
        }

        private void ButtonAvtoriz_Click(object sender, RoutedEventArgs e)
        {
            string login = TextBoxLogin.Text.Trim();
            string password = TextBoxPassword.Text.Trim();

            try
            {
                var user = db.Users.SqlQuery(
                    "SELECT * FROM Users WHERE login = @login AND password = @password",
                    new System.Data.SqlClient.SqlParameter("@login", login),
                    new System.Data.SqlClient.SqlParameter("@password", password)
                ).FirstOrDefault();

                if (user != null)
                {
                    MessageBox.Show($"Добро пожаловать, {user.surname}!", "Успешная авторизация");
                    WindowUsers windowuser = new WindowUsers();
                    windowuser.Show();
                    this.Close();
                }
                else
                {
                    MessageBox.Show("Неправильный логин или пароль.", "Login erorr");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Во время входа в систему произошла ошибка: {ex.Message}", "Erorr");
            }
        }

        private void ButtonExzit_Click(object sender, RoutedEventArgs e)
        {
            GlavWindow windowuser = new GlavWindow();
            windowuser.Show();
            this.Close();
        }
    }
    
}
